export interface Transaction {
    stockName: string;
    amount: number;
    price: number;
    type: string;
    date: string;
}
//ניתן להוסיף תאריך