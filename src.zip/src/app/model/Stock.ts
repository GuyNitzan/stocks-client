export interface Stock {
    name: string;
    value: number;
    lastValue: number;
    openValue: number;
}