export interface userStock {
    name: string;
    amount: number;
    value: number;
    averagePurchasePrice: number;
}