export interface Balance {
    value: number;
}